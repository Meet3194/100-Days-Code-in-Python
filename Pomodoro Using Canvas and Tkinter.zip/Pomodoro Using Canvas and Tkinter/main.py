import tkinter
from tkinter import *
import math

FONT = ("Courier", 30, "bold")
FONT2 = ("Courier", 18, "bold")
GREEN = "#357C3C"
WHITE = "#ECECEC"
WORK = "#FF1818"
SHORT_BREAK = "#FFC300"
LONG_BREAK = "#5463FF"
START = "#FF5F00"
STOP = "#B91646"
RESET = "#293462"
WORK_MIN = 1
SHORT_BREAK_MIN = 0.1
LONG_BREAK_MIN = 0.5
reps = 0
timer = None


def start_timer():
    global reps
    reps += 1

    work_sec = WORK_MIN * 60
    short_break_sec = SHORT_BREAK_MIN * 60
    long_break_sec = LONG_BREAK_MIN * 60

    if reps % 8 == 0:
        count_down(long_break_sec)
        label1.config(text="Take a Long Break.!", fg=LONG_BREAK, bg=WHITE, font=FONT)
    elif reps % 2 == 0:
        count_down(short_break_sec)
        label1.config(text="Take a Short Break.!", fg=SHORT_BREAK, bg=WHITE, font=FONT)
    else:
        count_down(work_sec)
        label1.config(text="Work or Study till the Timer Stops.\n Then take a Short or Long Break.!",
                      fg=WORK, bg=WHITE, font=FONT)


def stop_timer():
    window.after_cancel(timer)
    label1.config(text="Time won't stop for you.! \n SO KEEP GRINDING....\n Reset it and Start Again.!", fg=STOP,
                  bg=WHITE, font=FONT)


def reset_timer():
    window.after_cancel(timer)
    canvas.itemconfig(timer_text, text="00:00")
    label1.config(text="Let's Try using Pomodoro Technique Again.!", fg=RESET, bg=WHITE, font=FONT)
    label2.config(text="")
    global reps
    reps = 0


def count_down(count):
    count_mins = math.floor(count / 60)
    count_seconds = count % 60
    if count_seconds < 10:
        count_seconds = f"0{count_seconds}"
    canvas.itemconfig(timer_text, text=f"{count_mins}:{count_seconds}")
    if count > 0:
        global timer
        timer = window.after(1000, count_down, count - 1)
    else:
        start_timer()
        marks = ""
        work_sessions = math.floor(reps / 2)
        for _ in range(work_sessions):
            marks += "✔"
        label2.config(text=marks)


window = Tk()
window.title("Pomodoro")
window.config(padx=100, pady=100, bg=WHITE)

label1 = tkinter.Label(text="Let's Try using Pomodoro Technique", fg=GREEN, bg=WHITE, font=FONT)
label1.grid(row=0, column=1)

canvas = Canvas(width=360, height=360, bg=WHITE, highlightthickness=0)
tomato_image = PhotoImage(file="tomato2.png")
canvas.create_image(180, 180, image=tomato_image)
canvas.grid(row=1, column=1)
timer_text = canvas.create_text(185, 210, text="00:00", fill=WHITE, font=FONT)

button1 = Button(text="[START]", font=FONT2, fg=START, bg=WHITE, highlightthickness=0, command=start_timer)
button1.grid(row=2, column=0)

button3 = Button(text="X STOP X", font=FONT2, fg=STOP, bg=WHITE, highlightthickness=0, command=stop_timer)
button3.grid(row=2, column=1)

button2 = Button(text="RESET(0)", font=FONT2, fg=RESET, bg=WHITE, highlightthickness=0, command=reset_timer)
button2.grid(row=2, column=2)

label2 = tkinter.Label(text="✔", fg=GREEN, bg=WHITE, font=FONT)
label2.grid(row=3, column=1)

window.mainloop()
