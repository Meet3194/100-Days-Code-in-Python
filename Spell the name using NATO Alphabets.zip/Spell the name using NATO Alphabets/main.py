import pandas
# with open("nato_phonetic_alphabet.csv") as words:
#     alphabets = words.readlines()
#     print(alphabets)
#

data = pandas.read_csv("nato_phonetic_alphabet.csv")
# print(data)
phonetic_dictionary = {row.letter: row.code for (index, row) in data.iterrows()}
# # # print(phonetic_dictionary)
# #
word = input("Enter a word : ").upper()
output_word = {phonetic_dictionary[letter] for letter in word}
print(output_word)
