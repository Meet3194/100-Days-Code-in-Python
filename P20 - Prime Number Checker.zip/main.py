#Write your code below this line 👇





#Write your code above this line 👆
    
#Do NOT change any of the code below👇
n = int(input("Check this number: "))
def prime_checker(number=n):
    flag = False
    if n == 1:
        print("Its neither a prime nor composite number.")
    elif n>1:
        for i in range(2,n):
            if n%i == 0:
                flag = True

        if flag:
            print("It's not a prime number.")
        else:
            print("It's a prime number")
prime_checker()

