import random
import turtle as t
import random

jim = t.Turtle()
jim.speed("fastest")
jim.penup()
jim.setheading(219)
jim.forward(640)
jim.setheading(0)
dots = 143

colours= ["red", "green", "yellow", "blue", "pink", "orange", "purple", "gray", "aqua", "teal"]

for dot_count in range(1, dots + 1):
    jim.dot(20, random.choice(colours))

    jim.forward(80)

    if dot_count % 13 == 0:

        jim.setheading(90)
        jim.forward(80)
        jim.setheading(180)
        jim.forward(1040)
        jim.setheading(0)

screen = t.Screen()
screen.exitonclick()
