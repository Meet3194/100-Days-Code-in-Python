#Write your code below this row 👇
even=0
for num in range(1,101):
    if num%2==0:
        even += num
print(even)