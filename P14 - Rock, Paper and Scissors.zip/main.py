import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇

choice = input("what do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors. ")
user_option = int(choice)

if (user_option == 0):
  print(rock)
elif(user_option == 1):
  print(paper)
else:
  print(scissors)

comp_option = random.randint(0,2)
if(comp_option==0):
  print("Computer Choose \n" +rock)
elif(comp_option==1):
  print("Computer Choose \n" +paper)
else:
  print("Computer Choose \n" +scissors)

if user_option==0 and comp_option==1:
  print("You lose")
elif user_option==0 and comp_option==2:
  print("You won")
elif user_option==1 and comp_option==0:
  print("You won")
elif user_option==1 and comp_option==2:
  print("You lose")
elif user_option==2 and comp_option==0:
  print("You lose")
elif user_option==2 and comp_option==1:
  print("You won")
elif user_option==comp_option:
  print("It's a draw")
else:
  print("You have chose a wrong number. You lose.!")
  


