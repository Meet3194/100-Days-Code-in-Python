import pandas
# with open("nato_phonetic_alphabet.csv") as words:
#     alphabets = words.readlines()
#     print(alphabets)
#

data = pandas.read_csv("nato_phonetic_alphabet.csv")
# print(data)
phonetic_dictionary = {row.letter: row.code for (index, row) in data.iterrows()}
# # # print(phonetic_dictionary)
# #
def nato():
    word = input("Enter a word : ").upper()
    try:
        output_word = {phonetic_dictionary[letter] for letter in word}
    except KeyError:
        print(f"Entered word {word} consist of numbers or symbols which is not acceptable. Please use only alphabets.!")
        nato()
    else:
        print(output_word)
nato()