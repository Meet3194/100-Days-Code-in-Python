# with open("weather_data.csv") as weather_list:
#     data = weather_list.readlines()
#     print(data)

# import csv
#
# with open("weather_data.csv") as weather_list:
#     data = csv.reader(weather_list)
#     # for weather in data:
#     #     print(weather)
#
#     temperature = []
#     for temp in data:
#         if temp[1] != "temp":
#             temperature.append(int(temp[1]))
#     print(temperature)


#
# data = pandas.read_csv("weather_data.csv")
# print(data)
# print(data["temp"])
# average = data["temp"].mean()
# minimum = data["temp"].min()
# maximum = data["temp"].max()
# print(average)
# print(minimum)
# print(maximum)

# max_tempdata = (data[data.temp == data["temp"].max()])
# print(max_tempdata)

# monday = data[data.day == "Monday"]
# print((monday.temp)

# hudl = {"Emp_ID": [1, 2, 3, 4, 5],
#         "Name": ["Onkar", "Meet", "Pratik", "Rahul", "Mahesh"]}
# 
# hudl_data = pandas.DataFrame(hudl)
# print(hudl_data)
# hudl_data.to_csv("hudl_data.csv")

import pandas

data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")
gray_squirrels = len(data[data["Primary Fur Color"] == "Gray"])
black_squirrels = len(data[data["Primary Fur Color"] == "Black"])
cinnamon_squirrels = len(data[data["Primary Fur Color"] == "Cinnamon"])
print(gray_squirrels)
print(black_squirrels)
print(cinnamon_squirrels)

squirrels_count = {
        "Primary Fur Color": ["Gray", "Black", "Cinnamon"],
        "Count": [gray_squirrels, black_squirrels, cinnamon_squirrels]
}
squirrels_count_data = pandas.DataFrame(squirrels_count)
print(squirrels_count_data)
squirrels_count_data.to_csv("squirrels_data.csv")