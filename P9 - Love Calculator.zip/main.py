# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

name = str(name1+name2)
lname = name.lower()

t=lname.count('t')
r=lname.count('r')
u=lname.count('u')
e=lname.count('e')

a=t+r+u+e

l=lname.count('l')
o=lname.count('o')
v=lname.count('v')
e=lname.count('e')
b=l+o+v+e

cal=int(str(a)+str(b))


if cal<10 or cal>90:
    print(f"Your score is {cal}, you go together like coke and mentos.")
elif cal>=40 and cal<=50:
    print(f"Your score is {cal}, you are alright together.")
else:
    print(f"Your score is {cal}")

#David Beckham & Victoria Beckham
