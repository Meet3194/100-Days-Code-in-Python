import tkinter
from tkinter import *

window = Tk()
window.title("Day27-Buttons")
window.minsize(width=600, height=600)
window.config(padx=50, pady=50)

label1 = tkinter.Label(text="Hello", font=["Arial", 24, "bold"])
label1.grid(row=0, column=0)


def button_clicked():
    input_data = input.get()
    label1.configure(text=input_data)


def button_exit():
    exit()


button1 = Button(text="Click Me", command=button_clicked)
button1.grid(row=1, column=1)

button2 = Button(text="Exit", command=button_exit)
button2.grid(row=0, column=2)

input = Entry(width=15)
input.grid(row=2, column=3)

window.mainloop()
