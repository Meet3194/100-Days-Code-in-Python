import tkinter
from tkinter import *

window = Tk()
window.title("Miles to Kilometer converter")
window.minsize(width=300, height=300)
window.config(padx=50, pady=50)

input = Entry(width=10)
input.grid(row=0, column=1)

label1 = tkinter.Label(text="Miles", font=["Arial", 18, "bold"])
label1.grid(row=0, column=2)
label1.config(padx=10, pady=10)

label2 = tkinter.Label(text="is equal to", font=["Arial", 18, "bold"])
label2.grid(row=1, column=0)
label2.config(padx=10, pady=10)

label3 = tkinter.Label(text="0", font=["Arial", 18, "bold"])
label3.grid(row=1, column=1)
label3.config(padx=10, pady=10)

label4 = tkinter.Label(text="Kilometers", font=["Arial", 18, "bold"])
label4.grid(row=1, column=2)
label4.config(padx=10, pady=10)


def cal():
    input_data = float(input.get())
    km = (input_data * 1.6)
    label3.configure(text=f"{int(km)}")


button1 = Button(text="Calculate", command=cal)
button1.grid(row=2, column=1)

window.mainloop()
