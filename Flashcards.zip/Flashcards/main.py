from tkinter import *
import pandas
import random

BACKGROUND_COLOR = "#B1DDC6"
current_card = {}
to_learn = {}

try:
    datawords = pandas.read_csv("data/words_to_learn.csv")
except FileNotFoundError:
    original_data = pandas.read_csv("data/Japanese_words.csv")
    to_learn = original_data.to_dict(orient="records")
else:
    to_learn = datawords.to_dict(orient="records")


def is_known():
    to_learn.remove(current_card)
    next_card()
    known_data = pandas.DataFrame(to_learn)
    known_data.to_csv("data/words_to_learn.csv", index=False)


def next_card():
    global current_card, flip_timer
    window.after_cancel(flip_timer)
    current_card = random.choice(to_learn)
    canvas.itemconfig(card_title, text=current_card["WORDS"], fill="black")
    canvas.itemconfig(card_word, text=current_card["JAPANESE"], fill="black")
    canvas.itemconfig(card_background, image=front_card_img)
    flip_timer = window.after(3000, func=flip_card)


def flip_card():
    canvas.itemconfig(card_title, text=current_card["WORDS"], fill="white")
    canvas.itemconfig(card_word, text=current_card["ENGLISH"], fill="white")
    canvas.itemconfig(card_background, image=back_card_img)


window = Tk()
window.title("Flashcards")
window.config(padx=50, pady=50, bg=BACKGROUND_COLOR)
flip_timer = window.after(3000, func=flip_card)

data = pandas.read_csv("data/Japanese_words.csv")

canvas = Canvas(width=800, height=526)
front_card_img = PhotoImage(file="images/card_front.png")
back_card_img = PhotoImage(file="images/card_back.png")
card_background = canvas.create_image(400, 263, image=front_card_img)
card_title = canvas.create_text(400, 150, font=("Courier", 40, "bold"))
card_word = canvas.create_text(400, 263, font=("Courier", 40, "italic"))
canvas.config(bg=BACKGROUND_COLOR, highlightthickness=0)
canvas.grid(row=0, column=0, columnspan=2)

wrong = PhotoImage(file="images/wrong.png")
wrong_check = Button(image=wrong, bg=BACKGROUND_COLOR, highlightthickness=0, command=next_card)
wrong_check.grid(row=1, column=0)

right = PhotoImage(file="images/right.png")
right_check = Button(image=right, bg=BACKGROUND_COLOR, highlightthickness=0, command=is_known)
right_check.grid(row=1, column=1)

next_card()

window.mainloop()
