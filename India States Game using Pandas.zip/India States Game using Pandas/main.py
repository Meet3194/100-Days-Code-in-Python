import turtle
from turtle import Screen

screen = Screen()
screen.title("States in India")
picture = "blank_states_india_map.gif"
screen.addshape(picture)
turtle.shape(picture)


import pandas
# states_data = {
#     "States" : ["Himachal Pradesh", "Punjab", "Uttarakhand",
#                 "Haryana", "Rajasthan", "Uttar Pradesh", "Bihar",
#                 "Gujarat", "Madhya Pradesh", "Jharkhand", "West Bengal", "Maharashtra",
#                 "Chhattisgarh", "Odisha", "Goa", "Karnataka", "Telangana",
#                 "Andhra Pradesh", "Kerala", "Tamil Nadu",
#                 "Sikkim", "Arunachal Pradesh", "Assam", "Meghalaya", "Nagaland", "Manipur", "Tripura", "Mizoram"],
#     "x-cor": [-123.0, -156.0, -81.0, -136.0, -196.0, -40.0, 72.0, -243.0, -93.0, 61.0, 123.0, -160.0, -11.0, 47.0, -191.0, -152.0, -80.0, -71.0, -137.0, -91.0, 138.0, 275.0, 234.0, 196.0, 277.0, 262.0, 213.0, 240.0],
#     "y-cor": [221.0, 191.0, 184.0, 149.0, 79.0, 87.0, 60.0, -8.0, -9.0,  8.0, -9.0, -96.0, -52.0, -70.0, -195.0, -190.0, -136.0, -196.0, -307.0, -298.0, 107.0, 122.0, 73.0, 53.0, 66.0, 34.0, 11.0, -1.0]
# }
#
# states = pandas.DataFrame(states_data)
# print(states)
# states.to_csv("indian_states.csv")

# def get_co_ordinates(x, y):
#     print(x, y)
#
#
# turtle.onscreenclick(get_co_ordinates)
# turtle.mainloop()


# print(user_inputs)

states_data = pandas.read_csv("indian_states.csv")
all_states = states_data["States"].to_list()
# print(all_states)
# print(states_data)
guessed_state = []

while len(guessed_state) < 28:

    user_inputs = screen.textinput(title=f"{len(guessed_state)}/28 Guess the Indian States.!", prompt="Enter the name of states here.").title()

    if user_inputs == "Exit":
        missing_states = []
        for state in all_states:
            if state not in guessed_state:
                missing_states.append(state)
            missed_states = pandas.DataFrame(missing_states)
            missed_states.to_csv("states_to_learn.csv")
        break

    if user_inputs in all_states:
        guessed_state.append(user_inputs)
        ans = turtle.Turtle()
        ans.hideturtle()
        ans.penup()
        correct_answer = states_data[states_data.States == user_inputs]
        ans.goto(int(correct_answer["x-cor"]), int(correct_answer["y-cor"]))
        ans.write(user_inputs, font=("Arial", 12, "bold"))
