# import smtplib
#
# my_email = "gandhi.meet3194@gmail.com"
# password = "mfnjmdjshubputdd"
#
# with smtplib.SMTP("smtp.gmail.com") as connection:
#     connection.starttls()
#     connection.login(user=my_email, password=password)
#     connection.sendmail(
#         from_addr=my_email,
#         to_addrs="patildheeraj56@gmail.com",
#         msg="Subject:Python Email Test\n\nHello Dheeraj, sorry to bother you.\nHope your studies are going good.!"
#             "\n\nArigatoo Goziamas."
#     )

# import datetime as dt
# import smtplib
# import random
#
# my_email = "gandhi.meet3194@gmail.com"
# password = "mfnjmdjshubputdd"
#
# now = dt.datetime.now()
# current_day = now.weekday()
#
# if current_day == 3:
#     with open("quotes.txt") as data:
#         all_quotes = data.readlines()
#         random_message = random.choice(all_quotes)
#
#     with smtplib.SMTP("smtp.gmail.com") as connection:
#         connection.starttls()
#         connection.login(user=my_email, password=password)
#         connection.sendmail(
#             from_addr=my_email,
#             to_addrs=my_email,
#             msg=f"Subject:Random Message Test\n\n{random_message}"
#         )

from datetime import datetime
import pandas
import smtplib
import random

my_email = "gandhi.meet3194@gmail.com"
password = "mfnjmdjshubputdd"
today = datetime.now()
today_tuple = (today.month, today.day)


data = pandas.read_csv("birthdays.csv")
birthday_dict = {(data_row["month"], data_row["day"]): data_row for (index, data_row) in data.iterrows()}

if today_tuple in birthday_dict:
    birthday_person = birthday_dict[today_tuple]
    file_path = f"letter_templates/letter_{random.randint(1,3)}"
    with open(file_path) as letter_file:
        content = letter_file.read()
        content = content.replace("[NAME]", birthday_person["name"])

    with smtplib.SMTP("smtp.gmail.com") as connection:
        connection.starttls()
        connection.login(user=my_email, password=password)
        connection.sendmail(
           from_addr=my_email,
            to_addrs=birthday_person["email"],
            msg=f"Subject:Happy Birthday.!\n\n{content}"
         )